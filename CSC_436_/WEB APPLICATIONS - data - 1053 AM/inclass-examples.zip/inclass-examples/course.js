
class Course {
    constructor(name, quarter) {
        this.name = name;
        this.quarter = quarter;
    }
}